package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivityTongseng1 extends Activity {
    private Button btnmasaktongseng;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_tongseng1);

        btnmasaktongseng = (Button) findViewById(R.id.btnmasaktongseng);
        btnmasaktongseng.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent masaktongseng = new Intent(Main3ActivityTongseng1.this, Main3ActivityTongseng2.class);
                Main3ActivityTongseng1.this.startActivity(masaktongseng);

            }
        });
    }
}

