package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivitySayurSop1 extends Activity {
    private Button btnmasaksup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_sayur_sop1);

        btnmasaksup = (Button) findViewById(R.id.btnmasaksup);
        btnmasaksup.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent masaksup = new Intent(Main3ActivitySayurSop1.this, Main3ActivitySayurSop2.class);
                Main3ActivitySayurSop1.this.startActivity(masaksup);

            }
        });
    }
}