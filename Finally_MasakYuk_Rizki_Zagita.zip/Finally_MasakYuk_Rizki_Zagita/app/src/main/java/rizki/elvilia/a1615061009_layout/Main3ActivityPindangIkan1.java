package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivityPindangIkan1 extends Activity {
    private Button btnmasakpindangikan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_pindang_ikan1);

        btnmasakpindangikan = (Button) findViewById(R.id.btnmasakpindangikan);
        btnmasakpindangikan.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent masakpindang = new Intent(Main3ActivityPindangIkan1.this, Main3ActivityPindangIkan2.class);
                Main3ActivityPindangIkan1.this.startActivity(masakpindang);

            }
        });
    }
}
