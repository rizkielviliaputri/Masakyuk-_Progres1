package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivityRendang1 extends Activity {
    private Button btnmasakrendang;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_rendang1);

        btnmasakrendang = (Button) findViewById(R.id.btnmasakrendang);
        btnmasakrendang.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent masakrendang = new Intent(Main3ActivityRendang1.this, Main3ActivityRendang2.class);
                Main3ActivityRendang1.this.startActivity(masakrendang);

            }
        });
    }
}
