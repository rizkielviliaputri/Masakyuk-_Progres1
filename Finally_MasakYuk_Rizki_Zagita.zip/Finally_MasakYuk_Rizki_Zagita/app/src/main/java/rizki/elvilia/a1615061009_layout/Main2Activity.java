package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import java.util.ArrayList;

public class Main2Activity extends Activity {

    private Button btnnasgor, btnrendang, btnsoto, btnsate, btnpindangikan, btnpecel, btncapcay, btnsup, btntongseng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnnasgor = (Button) findViewById(R.id.btnnasgor);
        btnrendang = (Button) findViewById(R.id.btnrendang);
        btnsoto = (Button) findViewById(R.id.btnsoto);
        btnsate = (Button) findViewById(R.id.btnsate);
        btnpindangikan = (Button) findViewById(R.id.btnpindangikan);
        btnpecel = (Button) findViewById(R.id.btnpecel);
        btncapcay = (Button) findViewById(R.id.btncapcay);
        btnsup = (Button) findViewById(R.id.btnsup);
        btntongseng = (Button)  findViewById(R.id.btntongseng);

        btnnasgor.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent nasgor = new Intent(Main2Activity.this, Main3ActivityNasgor.class);
                Main2Activity.this.startActivity(nasgor);

            }
        });
        btnrendang.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent rendang = new Intent(Main2Activity.this, Main3ActivityRendang1.class);
                Main2Activity.this.startActivity(rendang);

            }
        });

        btnsoto.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent soto = new Intent(Main2Activity.this, Main3ActivitySotoAyam1.class);
                Main2Activity.this.startActivity(soto);

            }
        });

        btnsate.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent sate = new Intent(Main2Activity.this, Main3ActivitySate1.class);
                Main2Activity.this.startActivity(sate);

            }
        });

        btnpindangikan.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent pindangikan = new Intent(Main2Activity.this, Main3ActivityPindangIkan1.class);
                Main2Activity.this.startActivity(pindangikan);

            }
        });

        btnpecel.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent pecel = new Intent(Main2Activity.this, Main3ActivityPecel1.class);
                Main2Activity.this.startActivity(pecel);

            }
        });


        btncapcay.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent capcay = new Intent(Main2Activity.this, Main3ActivityCapcay1.class);
                Main2Activity.this.startActivity(capcay);

            }
        });

        btnsup.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent sayursup = new Intent(Main2Activity.this, Main3ActivitySayurSop1.class);
                Main2Activity.this.startActivity(sayursup);

            }
        });

        btntongseng.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent tongseng = new Intent(Main2Activity.this, Main3ActivityTongseng1.class);
                Main2Activity.this.startActivity(tongseng);

            }
        });
    }
}

