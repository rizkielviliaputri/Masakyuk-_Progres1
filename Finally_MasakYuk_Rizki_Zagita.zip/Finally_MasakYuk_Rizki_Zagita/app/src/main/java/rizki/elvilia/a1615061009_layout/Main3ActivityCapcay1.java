package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivityCapcay1 extends Activity {
    private Button btnmasakcapcay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_capcay1);

        btnmasakcapcay = (Button) findViewById(R.id.btnmasakcapcay);
        btnmasakcapcay.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent masakcapcay = new Intent(Main3ActivityCapcay1.this, Main3ActivityCapcay2.class);
                Main3ActivityCapcay1.this.startActivity(masakcapcay);

            }
        });
    }
}