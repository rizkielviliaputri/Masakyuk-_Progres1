package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivityNasgor extends Activity {
    private Button btnmasaknasgor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_nasgor);

        btnmasaknasgor = (Button) findViewById(R.id.btnmasaknasgor);
        btnmasaknasgor.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent masaknasgor = new Intent(Main3ActivityNasgor.this, Main3ActivityNasgor2.class);
                Main3ActivityNasgor.this.startActivity(masaknasgor);

            }
        });
    }
}
