package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import java.util.ArrayList;

public class Main2Activity extends Activity {

    private Button btnnasgor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnnasgor = (Button) findViewById(R.id.btnnasgor);
        btnnasgor.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent nasgor = new Intent(Main2Activity.this, Main3ActivityNasgor.class);
                Main2Activity.this.startActivity(nasgor);

            }
        });
    }
}

