package rizki.elvilia.a1615061009_layout;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main3ActivityNasgor2 extends Activity {
    private Button btnselesainasgor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_nasgor2);

        btnselesainasgor = (Button) findViewById(R.id.btnselesainasgor);
        btnselesainasgor.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent selesaimasaknasgor = new Intent(Main3ActivityNasgor2.this, Main2Activity.class);
                Main3ActivityNasgor2.this.startActivity(selesaimasaknasgor);

            }
        });
    }
}
