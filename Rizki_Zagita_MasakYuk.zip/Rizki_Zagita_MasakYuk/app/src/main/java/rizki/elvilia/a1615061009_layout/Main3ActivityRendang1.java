package rizki.elvilia.a1615061009_layout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Main3ActivityRendang1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3_rendang1);
    }
}
